CREATE DATABASE sequelize_passport;
USE sequelize_passport;

